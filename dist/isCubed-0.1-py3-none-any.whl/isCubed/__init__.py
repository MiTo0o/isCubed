def isCubed(num):
  return round(num**(1/3)) ** 3 == num